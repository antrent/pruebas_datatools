package com.springboot.app.empresas.controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.app.empresas.models.entity.Empresa;
import com.springboot.app.empresas.models.service.IEmpresaService;

@RestController
public class EmpresaController {

	@Autowired
	private IEmpresaService empresaService;
	
	@GetMapping("/listar")
	public List<Empresa> listar(){
		return empresaService.findAll().stream().map(empresa ->{
			return empresa;
		}).collect(Collectors.toList());
	}
	
	@GetMapping("/ver/{id}")
	public Empresa detalle(@PathVariable Long id) {
		Empresa empresa = empresaService.findById(id);
		return empresa;
	}

	@PostMapping("/crear")
	@ResponseStatus(HttpStatus.CREATED)
	public Empresa crear(@RequestBody Empresa emppresa) {
		return empresaService.save(emppresa);
	}	

	@PutMapping("/editar/{id}")
	@ResponseStatus(HttpStatus.CREATED)
	public Empresa editar(@RequestBody Empresa emppresa, @PathVariable Long id) {
		Empresa emppresaDb = empresaService.findById(id); 
		
		emppresaDb.setCiudad(emppresa.getCiudad());
		emppresaDb.setDepartamento(emppresa.getDepartamento());
		emppresaDb.setDireccion(emppresa.getDireccion());
		emppresaDb.setNombre(emppresa.getNombre());
		emppresaDb.setPais(emppresa.getPais());
		emppresaDb.setTelefono(emppresa.getTelefono());
		
		return empresaService.save(emppresaDb);
		
	}	

	@DeleteMapping("/eliminar/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void eliminar(@PathVariable Long id) {
		empresaService.deleteById(id); 
	}	
	
	
}
