package com.springboot.app.empresas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceEmpresasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceEmpresasApplication.class, args);
	}

}
