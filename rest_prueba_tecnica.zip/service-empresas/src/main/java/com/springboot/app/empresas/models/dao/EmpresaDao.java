package com.springboot.app.empresas.models.dao;

import org.springframework.data.repository.CrudRepository;

import com.springboot.app.empresas.models.entity.Empresa;


public interface EmpresaDao extends CrudRepository<Empresa, Long> {

}
