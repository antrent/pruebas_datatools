package com.springboot.app.empresas.models.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.app.empresas.models.dao.EmpresaDao;
import com.springboot.app.empresas.models.entity.Empresa;

@Service
public class EmpresaServiceImpl implements IEmpresaService{

	@Autowired
	private EmpresaDao empresaDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<Empresa> findAll() {
		return (List<Empresa>) empresaDao.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Empresa findById(Long id) {
		return empresaDao.findById(id).orElse(null);
	}

	@Override
	@Transactional
	public Empresa save(Empresa empresa) {
		return empresaDao.save(empresa);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		empresaDao.deleteById(id);
	}
	
}
