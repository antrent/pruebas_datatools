package com.springboot.app.empresas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceEmpresasApplicationTests {

	@Test
	void contextLoads() {
	}

}
