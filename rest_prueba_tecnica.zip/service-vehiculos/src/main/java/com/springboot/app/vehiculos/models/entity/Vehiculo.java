package com.springboot.app.vehiculos.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "vehiculos")
public class Vehiculo implements Serializable {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String placa;
	private String motor;
	private String chasis;
	private String modelo;
	
	@Column(name = "fecha_Matricula")
	@Temporal(TemporalType.DATE)
	private Date fechaMatricula;
	
	private String pasajerosSentados;
	private String pasajerosDePie;
	private String pesoSeco;
	private String pesoBruto;
	private String cantPuertas;
	private String marca;
	private String linea;
	private String idConductor;
	
	
	
	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getPlaca() {
		return placa;
	}



	public void setPlaca(String placa) {
		this.placa = placa;
	}



	public String getMotor() {
		return motor;
	}



	public void setMotor(String motor) {
		this.motor = motor;
	}



	public String getChasis() {
		return chasis;
	}



	public void setChasis(String chasis) {
		this.chasis = chasis;
	}



	public String getModelo() {
		return modelo;
	}



	public void setModelo(String modelo) {
		this.modelo = modelo;
	}



	public Date getFechaMatricula() {
		return fechaMatricula;
	}



	public void setFechaMatricula(Date fechaMatricula) {
		this.fechaMatricula = fechaMatricula;
	}



	public String getPasajerosSentados() {
		return pasajerosSentados;
	}



	public void setPasajerosSentados(String pasajerosSentados) {
		this.pasajerosSentados = pasajerosSentados;
	}



	public String getPasajerosDePie() {
		return pasajerosDePie;
	}



	public void setPasajerosDePie(String pasajerosDePie) {
		this.pasajerosDePie = pasajerosDePie;
	}



	public String getPesoSeco() {
		return pesoSeco;
	}



	public void setPesoSeco(String pesoSeco) {
		this.pesoSeco = pesoSeco;
	}



	public String getPesoBruto() {
		return pesoBruto;
	}



	public void setPesoBruto(String pesoBruto) {
		this.pesoBruto = pesoBruto;
	}



	public String getCantPuertas() {
		return cantPuertas;
	}



	public void setCantPuertas(String cantPuertas) {
		this.cantPuertas = cantPuertas;
	}



	public String getMarca() {
		return marca;
	}



	public void setMarca(String marca) {
		this.marca = marca;
	}



	public String getLinea() {
		return linea;
	}



	public void setLinea(String linea) {
		this.linea = linea;
	}

	


	public String getIdConductor() {
		return idConductor;
	}



	public void setIdConductor(String idConductor) {
		this.idConductor = idConductor;
	}




	private static final long serialVersionUID = 34394751003251939L;
	
}
