package com.springboot.app.vehiculos.models.dao;

import org.springframework.data.repository.CrudRepository;

import com.springboot.app.vehiculos.models.entity.Vehiculo;

public interface VehiculoDao extends CrudRepository<Vehiculo, Long> {

}
