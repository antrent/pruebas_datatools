package com.springboot.app.vehiculos.models.service;

import java.util.List;

import com.springboot.app.vehiculos.models.entity.Vehiculo;

public interface IVehiculoService {

	public List<Vehiculo> findAll();
	public Vehiculo findById(Long id);
	public Vehiculo save(Vehiculo vehiculo);
	public void  deleteById(Long id);	
}
