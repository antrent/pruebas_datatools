package com.springboot.app.vehiculos.controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.app.vehiculos.models.entity.Vehiculo;
import com.springboot.app.vehiculos.models.service.IVehiculoService;

@RestController
public class VehiculoController {

	@Autowired
	private IVehiculoService vehiculoService;
	
	@GetMapping("/listar")
	public List<Vehiculo> listar(){
		return vehiculoService.findAll().stream().map(vehiculo ->{
			return vehiculo;
		}).collect(Collectors.toList());
	}
	
	@GetMapping("/ver/{id}")
	public Vehiculo detalle(@PathVariable Long id) {
		Vehiculo vehiculo = vehiculoService.findById(id);
		return vehiculo;
	}
	
	@PostMapping("/crear")
	@ResponseStatus(HttpStatus.CREATED)
	public Vehiculo crear(@RequestBody Vehiculo vehiculo) {
		return vehiculoService.save(vehiculo);
	}	

	@PutMapping("/editar/{id}")
	@ResponseStatus(HttpStatus.CREATED)
	public Vehiculo editar(@RequestBody Vehiculo vehiculo, @PathVariable Long id) {
		Vehiculo vehiculoDb = vehiculoService.findById(id); 
		
		vehiculoDb.setMarca(vehiculo.getMarca());
		vehiculoDb.setPlaca(vehiculo.getPlaca());
		vehiculoDb.setModelo(vehiculo.getModelo());
		vehiculoDb.setLinea(vehiculo.getLinea());
		vehiculoDb.setMotor(vehiculo.getMotor());
		vehiculoDb.setCantPuertas(vehiculo.getCantPuertas());
		vehiculoDb.setPesoSeco(vehiculo.getPesoSeco());
		vehiculoDb.setPesoBruto(vehiculo.getPesoBruto());
		vehiculoDb.setChasis(vehiculo.getChasis());
		vehiculoDb.setPasajerosDePie(vehiculo.getPasajerosDePie());
		vehiculoDb.setPasajerosSentados(vehiculo.getPasajerosSentados());
		vehiculoDb.setFechaMatricula(vehiculo.getFechaMatricula());
		
		return vehiculoService.save(vehiculoDb);
		
	}	

	@DeleteMapping("/eliminar/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void eliminar(@PathVariable Long id) {
		vehiculoService.deleteById(id); 
	}	
	
}
