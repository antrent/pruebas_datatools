package com.springboot.app.conductores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceConductoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceConductoresApplication.class, args);
	}

}
