package com.springboot.app.conductores.controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.app.conductores.models.entity.Conductor;
import com.springboot.app.conductores.models.service.IConductorService;

@RestController
public class ConductorController {

	
	@Autowired
	private IConductorService conductorService;
	
	@GetMapping("/listar")
	public List<Conductor> listar(){
		
		System.out.println("antonio");
		return conductorService.findAll().stream().map(conductor ->{
			return conductor;
		}).collect(Collectors.toList());
	}
	
	@GetMapping("/ver/{id}")
	public Conductor detalle(@PathVariable Long id) {
		Conductor conductor = conductorService.findById(id);
		return conductor;
	}
	
	@PostMapping("/crear")
	@ResponseStatus(HttpStatus.CREATED)
	public Conductor crear(@RequestBody Conductor conductor) {
		return conductorService.save(conductor);
	}	

	@PutMapping("/editar/{id}")
	@ResponseStatus(HttpStatus.CREATED)
	public Conductor editar(@RequestBody Conductor conductor, @PathVariable Long id) {
		Conductor conductorDb = conductorService.findById(id); 
		
		conductorDb.setApellidos(conductor.getApellidos());
		conductorDb.setCiudad(conductor.getCiudad());
		conductorDb.setDepartamento(conductor.getDepartamento());
		conductorDb.setDireccion(conductor.getDireccion());
		conductorDb.setNombres(conductor.getNombres());
		conductorDb.setPais(conductor.getPais());
		conductorDb.setTelefono(conductor.getTelefono());
		
		return conductorService.save(conductorDb);
		
	}	

	@DeleteMapping("/eliminar/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void eliminar(@PathVariable Long id) {
		conductorService.deleteById(id); 
	}	
	
}
