package com.springboot.app.conductores.models.dao;

import org.springframework.data.repository.CrudRepository;

import com.springboot.app.conductores.models.entity.Conductor;

public interface ConductorDao extends CrudRepository<Conductor, Long> {

}
