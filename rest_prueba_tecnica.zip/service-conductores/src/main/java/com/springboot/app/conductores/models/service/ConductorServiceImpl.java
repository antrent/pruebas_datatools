package com.springboot.app.conductores.models.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.app.conductores.models.dao.ConductorDao;
import com.springboot.app.conductores.models.entity.Conductor;

@Service
public class ConductorServiceImpl implements IConductorService {

	@Autowired
	private ConductorDao conductorDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<Conductor> findAll() {
		System.out.println("antonio2");
		return (List<Conductor>) conductorDao.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Conductor findById(Long id) {
		return conductorDao.findById(id).orElse(null);
	}

	@Override
	@Transactional
	public Conductor save(Conductor conductor) {
		return conductorDao.save(conductor);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		conductorDao.deleteById(id);
	}

	
	
}
