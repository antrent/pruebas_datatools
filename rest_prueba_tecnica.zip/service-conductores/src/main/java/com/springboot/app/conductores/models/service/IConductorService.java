package com.springboot.app.conductores.models.service;

import java.util.List;

import com.springboot.app.conductores.models.entity.Conductor;

public interface IConductorService {

	public List<Conductor> findAll();
	public Conductor findById(Long id);
	public Conductor save(Conductor conductor);
	public void  deleteById(Long id);
}
